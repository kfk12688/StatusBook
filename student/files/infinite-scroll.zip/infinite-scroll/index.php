<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="infinite scroll jquery, infinite scroll html, infinite scroll jquery example, infinite scroll jquery demo, simple infinite scroll jquery example, infinite scroll jquery demo download, infinite scroll jquery download, infinite scroll jquery tutorial, infinite scroll jquery ajax demo, infinite scroll jquery bootstrap, infinite scroll like facebook jquery">
	<meta name="keywords" content="infinite scroll jquery, infinite scroll html, infinite scroll jquery example, infinite scroll jquery demo, simple infinite scroll jquery example, infinite scroll jquery demo download, infinite scroll jquery download, infinite scroll jquery tutorial, infinite scroll jquery ajax demo, infinite scroll jquery bootstrap, infinite scroll like facebook jquery">
	<meta name="author" content="https://plus.google.com/+MuniAyothi/">
	<title>Infinite Scroll jQuery</title>
	<!-- Bootstrap -->
	<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,300,200' rel='stylesheet' type='text/css'>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	<link href="css/style.css" rel="stylesheet">

	<!-- Script -->
	<script src="js/jquery.min.js"></script>

</head>
<body>
	<!-- Static navbar -->
	<div role="navigation" class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" data-toggle="collapse"
					data-target=".navbar-collapse" class="navbar-toggle collapsed">
					<span class="sr-only">Toggle navigation</span> <span
						class="icon-bar"></span> <span class="icon-bar"></span> <span
						class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#">Infinite Scroll jQuery</a>
			</div>
			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav">
					<li class="active"><a href="http://www.smarttutorials.net/"><i class="fa fa-home"></i>Home</a></li>
					<li><a href="http://www.smarttutorials.net/demo/"> <i class="fa fa-book"></i> Demo </a></li>
					<li><a href="http://blog.smarttutorials.net/"> <i class="fa fa-bank"></i> Blog </a></li>
					<li><a href="http://forum.smarttutorials.net/"> <i class="fa fa-file"></i> Forum </a></li>
				</ul>
			</div>
			<!--/.nav-collapse -->
			<!--/.nav-collapse -->
		</div>
	</div>
	
	
	<!-- Begin page content -->
	
		<div class="container">
			<h2 class="title text-center" >Infinite Scroll jQuery</h2>
			<ul class="timeline" id="timeline-conatiner">
				<li class="year">2015</li>
				<li class="event">
					<h3 class="heading">Responsive PHP Quiz Script</h3>
					<span class="month"><i class="fa fa-calendar"></i> &nbsp; March 2015</span>
					
					<p>&nbsp;</p>
					<p>Demo : <a href="http://demo.smarttutorials.net/php-quiz-code/" target="_blank">PHP Quiz Script Demo</a></p>
					
					<p>Tutorial : <a href="http://www.smarttutorials.net/php-quiz-script/" target="_blank">PHP Quiz Script</a></p>
					<div class="text-center">
						<img class="img-responsive img-thumbnail" src="http://1.bp.blogspot.com/-5VF-5ZFx6fk/VRu6g9QaxjI/AAAAAAAAEB4/ipE14PIvqGQ/s1600/php-quiz-script.png">
					</div>
					<p>This version of Responsive PHP Quiz application has following new features are added. You may refer my previous versions of PHP MySQL quiz script tutorial to download php quiz script freely.</p>
					<blockquote>
						<ol>
							<li>Now users can share his/her results on Social networks (Facebook, Twitter, Google Plus, Reddit and Linkedin).</li>
							<li>The Quiz result page will contain all questions answered by the user along with correct answer.</li>
							<li>The Quiz result manage Grid has unique link to each taken Quiz result page, So user can refer his last Quiz results.</li>
							<li>The User can sort Quiz results on manage Grid using quiz taken date.</li>
						</ol>
					</blockquote>
				</li>
				<li class="event">
					<h3 class="heading">Invoice System Using jQuery PHP MySQL And Bootstrap</h3>
					<span class="month"><i class="fa fa-calendar"></i> &nbsp; March 2015 </span>
					<p>&nbsp;</p>
					<div class="embed-responsive embed-responsive-16by9">
						<iframe frameborder="0" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/AGawieZttJ0" class="embed-responsive-item"></iframe>
					</div>
					<p>&nbsp;</p>
					<p>Demo : <a href="http://demo.smarttutorials.net/invoice-script-php/" target="_blank">PHP Invoice System Demo</a></p>
					
					<p>Tutorial : <a href="http://www.smarttutorials.net/invoice-system-using-jquery-php-mysql-bootstrap/" target="_blank">Smart Invoice System</a></p>
					
					<p>This is an awesome tool for your marketing team and they can crack the deal at client’s doorstep. Order PDF Invoice System Script today! and increase sales. It just comes at a fraction of one time price. Grab the deal today.</p>
				</li>
				<li class="year">2014</li>
					
				<li class="event">
					<h3 class="heading">Ajax Multiple Image Upload With Resize Using jQuery PHP</h3>
					<span class="month"><i class="fa fa-calendar"></i> &nbsp; April 2014 </span>
					<p>&nbsp;</p>
					<p>Demo : <a href="http://demo.smarttutorials.net/ajax/" target="_blank">Demo Ajax Multiple Image Upload With Resize Using jQuery PHP </a></p>
					
					<p>Tutorial : <a href="http://www.smarttutorials.net/ajax-multiple-image-upload-with-resize-using-jquery-php-and-mysql/" target="_blank">Ajax Multiple Image Upload jQuery PHP</a></p>
					<div class="text-center">
						<img class="img-responsive img-thumbnail" src="http://4.bp.blogspot.com/-brQq4qtwFE4/VRu7EDU5n5I/AAAAAAAAECA/48vYeIZCo9Y/s1600/Ajax-Multiple-Image-Upload-Using-jQuery-PHP-and-MySQL.png">
					</div>
					<p>This is an awesome tool for your marketing team and they can crack the deal at client’s doorstep. Order PDF Invoice System Script today! and increase sales. It just comes at a fraction of one time price. Grab the deal today.</p>
				</li>
					
				<li class="event">
					<h3 class="heading">jQuery Autocomplete Mutiple Fields Using jQuery, Ajax, PHP and MySQL</h3>
					<span class="month"><i class="fa fa-calendar"></i> &nbsp; Feb 2014 </span>
					<p>&nbsp;</p>
					<p>Demo : <a href="http://demo.smarttutorials.net/jquery-autocomplete-mutiple-fields-ajax-php-mysql/" target="_blank">Demo jQuery AutoComplete </a></p>
					
					<p>Tutorial : <a href="http://www.smarttutorials.net/jquery-autocomplete-multiple-fields-using-ajax-php-mysql-example/" target="_blank">jQuery Autocomplete Mutiple Fields</a></p>
					<div class="text-center">
						<img class="img-responsive img-thumbnail" src="http://4.bp.blogspot.com/-mFaa6MsQhLc/VJZdqhgOTlI/AAAAAAAADx4/UpT1_wX68to/s1600/jQuery-Autocomplete-Mutiple-Fields-Using-jQuery-Ajax-PHP-and-MySQL.png">
					</div>
					<p>In this tutorial I am going to show how to populate multiple textfields using single jQuery autocomplete select. For example I am going search country name on country name textfield using jQuery autocomplete, finally results will show list of country names that matches your search. While selecting country name from any one of the search results, it will populate that corresponding country Number, Country Phone code and Country code will be populated automatically in their respective textfields.</p>
				</li>
			</ul>
			
			<div id="loader">
				<div class="sk-spinner sk-spinner-pulse"></div>
			</div>
		</div>
		<?php require_once 'content.php';?>
	<script src="js/jquery.min.js"></script>	
	<script src="js/bootstrap.min.js"></script>
	<script src="js/script.js"> </script>
  </body>
</html>
