<div id="hidden_container" style="display: none">
	<div id="1">
		<li class="event">
			<h3 class="heading">Responsive PHP Quiz Script</h3>
			<span class="month"><i class="fa fa-calendar"></i> &nbsp; March 2015</span>
			
			<p>&nbsp;</p>
			<p>Demo : <a href="http://demo.smarttutorials.net/php-quiz-code/" target="_blank">PHP Quiz Script Demo</a></p>
			
			<p>Tutorial : <a href="http://www.smarttutorials.net/php-quiz-script/" target="_blank">PHP Quiz Script</a></p>
			<div class="text-center">
				<img class="img-responsive img-thumbnail" src="http://1.bp.blogspot.com/-5VF-5ZFx6fk/VRu6g9QaxjI/AAAAAAAAEB4/ipE14PIvqGQ/s1600/php-quiz-script.png">
			</div>
			<p>This version of Responsive PHP Quiz application has following new features are added. You may refer my previous versions of PHP MySQL quiz script tutorial to download php quiz script freely.</p>
			<blockquote>
				<ol>
					<li>Now users can share his/her results on Social networks (Facebook, Twitter, Google Plus, Reddit and Linkedin).</li>
					<li>The Quiz result page will contain all questions answered by the user along with correct answer.</li>
					<li>The Quiz result manage Grid has unique link to each taken Quiz result page, So user can refer his last Quiz results.</li>
					<li>The User can sort Quiz results on manage Grid using quiz taken date.</li>
				</ol>
			</blockquote>
		</li>
		<li class="event">
			<h3 class="heading">Invoice System Using jQuery PHP MySQL And Bootstrap</h3>
			<span class="month"><i class="fa fa-calendar"></i> &nbsp; March 2015 </span>
			<p>&nbsp;</p>
			<div class="embed-responsive embed-responsive-16by9">
				<iframe frameborder="0" allowfullscreen="allowfullscreen" src="https://www.youtube.com/embed/AGawieZttJ0" class="embed-responsive-item"></iframe>
			</div>
			<p>&nbsp;</p>
			<p>Demo : <a href="http://demo.smarttutorials.net/invoice-script-php/" target="_blank">PHP Invoice System Demo</a></p>
			
			<p>Tutorial : <a href="http://www.smarttutorials.net/invoice-system-using-jquery-php-mysql-bootstrap/" target="_blank">Smart Invoice System</a></p>
			
			<p>This is an awesome tool for your marketing team and they can crack the deal at client�s doorstep. Order PDF Invoice System Script today! and increase sales. It just comes at a fraction of one time price. Grab the deal today.</p>
		</li>
	</div>
	
	<div id="2">
		<li class="event">
			<h3 class="heading">Ajax Multiple Image Upload With Resize Using jQuery PHP</h3>
			<span class="month"><i class="fa fa-calendar"></i> &nbsp; April 2014 </span>
			<p>&nbsp;</p>
			<p>Demo : <a href="http://demo.smarttutorials.net/ajax/" target="_blank">Demo Ajax Multiple Image Upload With Resize Using jQuery PHP </a></p>
			
			<p>Tutorial : <a href="http://www.smarttutorials.net/ajax-multiple-image-upload-with-resize-using-jquery-php-and-mysql/" target="_blank">Ajax Multiple Image Upload jQuery PHP</a></p>
			<div class="text-center">
				<img class="img-responsive img-thumbnail" src="http://4.bp.blogspot.com/-brQq4qtwFE4/VRu7EDU5n5I/AAAAAAAAECA/48vYeIZCo9Y/s1600/Ajax-Multiple-Image-Upload-Using-jQuery-PHP-and-MySQL.png">
			</div>
			<p>This is an awesome tool for your marketing team and they can crack the deal at client’s doorstep. Order PDF Invoice System Script today! and increase sales. It just comes at a fraction of one time price. Grab the deal today.</p>
		</li>
		
		<li class="event">
			<h3 class="heading">jQuery Autocomplete Mutiple Fields Using jQuery, Ajax, PHP and MySQL</h3>
			<span class="month"><i class="fa fa-calendar"></i> &nbsp; Feb 2014 </span>
			<p>&nbsp;</p>
			<p>Demo : <a href="http://demo.smarttutorials.net/jquery-autocomplete-mutiple-fields-ajax-php-mysql/" target="_blank">Demo jQuery AutoComplete </a></p>
			
			<p>Tutorial : <a href="http://www.smarttutorials.net/jquery-autocomplete-multiple-fields-using-ajax-php-mysql-example/" target="_blank">jQuery Autocomplete Mutiple Fields</a></p>
			<div class="text-center">
				<img class="img-responsive img-thumbnail" src="http://4.bp.blogspot.com/-mFaa6MsQhLc/VJZdqhgOTlI/AAAAAAAADx4/UpT1_wX68to/s1600/jQuery-Autocomplete-Mutiple-Fields-Using-jQuery-Ajax-PHP-and-MySQL.png">
			</div>
			<p>In this tutorial I am going to show how to populate multiple textfields using single jQuery autocomplete select. For example I am going search country name on country name textfield using jQuery autocomplete, finally results will show list of country names that matches your search. While selecting country name from any one of the search results, it will populate that corresponding country Number, Country Phone code and Country code will be populated automatically in their respective textfields.</p>
		</li>
	</div>
	
	<div id="3">
		<li class="event">
			<h3 class="heading">Facebook OAuth 2 Login Using PHP</h3>
			<span class="month"><i class="fa fa-calendar"></i> &nbsp; April 2013 </span>
			<p>&nbsp;</p>
			<p>Demo : <a href="http://demo.smarttutorials.net/fb_login/index.php" target="_blank">Demo Facebook OAuth 2 Login Using PHP  </a></p>
			
			<p>Tutorial : <a href="http://www.smarttutorials.net/facebook-oauth-2-login-using-php/" target="_blank">Facebook OAuth 2 Login Using PHP</a></p>
			
			<p>In this we are going to see how to implement Facebook OAuth 2 Login using PHP to our webapplications.</p>
		</li>
		
		<li class="event">
			<h3 class="heading">Login with Google OAuth 2 Using PHP and MySQL</h3>
			<span class="month"><i class="fa fa-calendar"></i> &nbsp; Feb 2013 </span>
			<p>&nbsp;</p>
			<p>Demo : <a href="http://demo.smarttutorials.net/google_login/" target="_blank">Demo Login with Google OAuth 2 </a></p>
			
			<p>Tutorial : <a href="http://www.smarttutorials.net/login-with-google-oauth-2-using-php-and-mysql/" target="_blank">Login with Google OAuth 2 Using PHP</a></p>
			
			<p>In this tutorial we are going to see how to implement Login with Google OAuth 2 Using PHP and MySQL to our web-application. Before continuing this please refer my previous tutorial on simple User Login and registration Using PHP and MySQLi.</p>
		</li>
	</div>
	
	<div id="4">
		<li class="event">
			<h3 class="heading">Gmail like layout Using HMTL and Twitter Bootstrap</h3>
			<span class="month"><i class="fa fa-calendar"></i> &nbsp; April 2012 </span>
			<p>&nbsp;</p>
			<p>Demo : <a href="http://demo.smarttutorials.net/gmai-layout-using-html-twitter-bootstrap/" target="_blank">Demo Gmail like layout  </a></p>
			
			<p>Tutorial : <a href="http://www.smarttutorials.net/gmail-like-layout-using-hmtl-twitter-bootstrap/" target="_blank">Gmail like layout Using HMTL and Twitter Bootstrap</a></p>
			
			<p>In this tutorial we are going to design a Gmail like layout using html and twitter bootstrap. Most of time we like to design some of the most popular layout on the web/internet. Once we designed ourself, we may feel sense of prideness that we made it. So here we are going to make most popular design on the internet i.e. Gmail layout, just follow this tutorial using bootstrap at the end you will make it yourself.</p>
		</li>
		
		<li class="event">
			<h3 class="heading">Drag and Drop File Upload jQuery PHP Ajax HTML5 MySQL and Bootstrap</h3>
			<span class="month"><i class="fa fa-calendar"></i> &nbsp; Feb 2012 </span>
			<p>&nbsp;</p>
			<p>Demo : <a href="http://demo.smarttutorials.net/jquery-file-upload/" target="_blank">Demo jQuery File Upload  </a></p>
			
			<p>Tutorial : <a href="http://www.smarttutorials.net/drag-drop-file-upload-jquery-php-ajax-html5-mysql-bootstrap/" target="_blank">Drag and Drop File Upload jQuery PHP Ajax HTML5 MySQL and Bootstrap</a></p>
			
			<p>In this tutorial we are going to implement drag and drop file upload using jQuery, PHP, ajax, html5, mysql and bootstrap. I am using blueimp jquery file upload plugin to implement this drag and drop image upload. Using this jQuery file upload plugin you can upload images, audio files(mp3, mp4, mpeg), video files, text files, zip files, word document and excel documents and etc.</p>
		</li>
	</div>
	
	
	<div id="5">
		<li class="event">
			<h3 class="heading">Ultra Lightweight Javascript Countdown Timer</h3>
			<span class="month"><i class="fa fa-calendar"></i> &nbsp; April 2011 </span>
			<p>&nbsp;</p>
			<p>Demo : <a href="http://demo.smarttutorials.net/jquery-countdown-timer/" target="_blank">Demo Javascript Countdown Timer   </a></p>
						
			<p>Tutorial : <a href="http://www.smarttutorials.net/javascript-countdown-timer/" target="_blank">Ultra Lightweight Javascript Countdown Timer</a></p>
						
			<p>This javascript countdown timer or jQuery countdown timer is very very simple and very light in weight..</p>
			<h2>Javascript Countdown Timer FlowChart:</h2>
			<p>I am using two functions to make this Javascript Timer countDown.</p>
			<blockquote><p>1. One is our own user defined function countDownTimer() function.<br>
2. Second one is Javascript default setTimeout() function.</p></blockquote>
	   </li>	
	   <li class="event">
			<h3 class="heading">Light Weight WordPress Frontend Ajax Login and Registration</h3>
			<span class="month"><i class="fa fa-calendar"></i> &nbsp; Feb 2011 </span>
			<p>&nbsp;</p>
			<p>Demo : <a href="http://www.smarttutorials.net/wordpress-frontend-login/" target="_blank">Demo WordPress Frontend </a></p>
			
			<p>Tutorial : <a href="http://www.smarttutorials.net/wordpress-frontend-ajax-login-registration/" target="_blank">Light Weight WordPress Frontend Ajax Login and Registration</a></p>
			
			<p>In this tutorial we are going to see WordPress frontend Ajax login and registration without using any plug-in. Once I thought Implementing frontend login in WordPress by own is one of the biggest diffcult task we ever do, but now it’s one easiest thing we ever do. So now we are implement this easiest thing in your project or blog just following few simple steps.
By default WordPress disables following GLOBAL variables POST, GET, SESSION and REQUEST for security reasons. So I think it very easy to done this WordPress login and registration using WordPress Ajax request.</p>
	   </li>	
	</div>
	
	<div id="6">
		<li class="event">
			<h3 class="heading">Instant Image Preview Before Upload Using jQuery</h3>
			<span class="month"><i class="fa fa-calendar"></i> &nbsp; April 2010 </span>
			<p>&nbsp;</p>
			<p>Demo : <a href="http://demo.smarttutorials.net/image-preview-before-upload-using-jquery/" target="_blank">Demo Image Preview </a></p>
			
			<p>Tutorial : <a href="http://www.smarttutorials.net/instant-image-preview-upload-using-jquery/" target="_blank">Instant Image Preview Before Upload Using jQuery</a></p>
			
			<p class="lead">In this tutorial we are going to see how to implement image preview before upload or before submitting form using jquery.</p>
			<p>So what we are doing here is once user select his image or images using input file field, then using <strong>change event</strong> of jQuery we get all the selected images. Then read the all selected images using <a target="_blank" title="FileReader Javascript" href="https://developer.mozilla.org/en-US/docs/Web/API/FileReaderhttp://">FileReader</a> and assign all the read images to image tag.</p>
		</li>
		
		<li class="event">
			<h3 class="heading">jQuery Autocomplete Post Tagging System Like In WordPress</h3>
			<span class="month"><i class="fa fa-calendar"></i> &nbsp; Feb 2010 </span>
			<p>&nbsp;</p>
			<p>Demo : <a href="http://demo.smarttutorials.net/jquery-autocomplete-post-tagging-system/" target="_blank">Demo jQuery Autocomplete Post Tagging System </a></p>
			
			<p>Tutorial : <a href="http://www.smarttutorials.net/jquery-autocomplete-post-tagging-system-like-in-wordpress/" target="_blank">jQuery Autocomplete Post Tagging System Like In WordPress</a></p>
			
			<p>In this artcile we are going to see how to implement post tagging system like in the blogger, wordpress or some of the CMS systems.</p>
			<p>We mostly use this type of post tagging system in all type of content management system. It always good idea to show suggestion when user tag their post in their content management system. let’s see how to implement this jQuery autocomplete in our blogger/wordpress post tagging system.</p>
		</li>
	</div>
</div>



