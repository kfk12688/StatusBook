********* ********* ********* ********* ********* 
1.0 SAMPLE FILES	
********* ********* ********* ********* *********

Calendar.htm	Standard implementation of the calendar via IFrame
Theme.htm	Standard implementation plus theme selector
Outlook.htm	calendar with outlook theme
2Calendar.htm	two calendars on the same page
noIFrame.htm	calendar without the iframe


********* ********* ********* ********* ********* 
2.0 DOCUMENTATION
********* ********* ********* ********* *********

The ScriptCalendar installation documentation may be found at
http://www.scriptcalendar.com/scrptcal/faq.aspx

The ScriptCalendar online Frequently Asked Questions may be found at
http://www.scriptcalendar.com/scrptcal/faq.aspx

The ScriptCalendar class property documentation may be found at
http://www.scriptcalendar.com/scrptcal/properties.aspx

********* ********* ********* ********* ********* 
3.0 NOTES
********* ********* ********* ********* *********

The FAQ is the most useful source of information.  Please visit it
for questions regarding the software.

********* ********* ********* ********* ********* 
4.0 EDITOR
********* ********* ********* ********* *********

The event editor can be found in the "sccomponents" folder.
It is the "scedit.htm" file.

